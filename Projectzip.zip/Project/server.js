const http = require('http');
const fs = require('fs');
const path = require('path');

const root = __dirname;
const types = { '.html': 'text/html', '.css': 'text/css', '.js': 'application/javascript' };

http.createServer((request, response) => {
  const pathname = request.url.split('?')[0] === '/' ? '/index.html' : request.url.split('?')[0];
  const file = path.join(root, decodeURIComponent(pathname));
  fs.readFile(file, (error, content) => {
    if (error) { response.writeHead(404); response.end('Not found'); return; }
    response.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' });
    response.end(content);
  });
}).listen(5173, '0.0.0.0', () => console.log('HemoLink running at http://localhost:5173'));
